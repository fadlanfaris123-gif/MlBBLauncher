package com.example.mlbblauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText deviceIdInput;
    private EditText packageInput;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences("launcher_settings", MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("MLBB Launcher");
        title.setTextSize(25);
        layout.addView(title, matchWrap());

        TextView note = new TextView(this);
        note.setText("Simpan Device ID dan buka aplikasi MLBB. Device ID tidak digunakan untuk login akun.");
        note.setPadding(0, pad / 2, 0, pad / 2);
        layout.addView(note, matchWrap());

        deviceIdInput = new EditText(this);
        deviceIdInput.setHint("Device ID (opsional)");
        deviceIdInput.setSingleLine(false);
        deviceIdInput.setText(preferences.getString("device_id", ""));
        layout.addView(deviceIdInput, matchWrap());

        packageInput = new EditText(this);
        packageInput.setHint("Package aplikasi MLBB");
        packageInput.setSingleLine(true);
        packageInput.setText(preferences.getString("package_name", "com.mobile.legends"));
        layout.addView(packageInput, matchWrap());

        Button saveButton = new Button(this);
        saveButton.setText("SIMPAN");
        saveButton.setOnClickListener(v -> {
            preferences.edit()
                .putString("device_id", deviceIdInput.getText().toString().trim())
                .putString("package_name", packageInput.getText().toString().trim())
                .apply();
            Toast.makeText(this, "Pengaturan tersimpan di perangkat", Toast.LENGTH_SHORT).show();
        });
        layout.addView(saveButton, matchWrap());

        Button launchButton = new Button(this);
        launchButton.setText("BUKA MOBILE LEGENDS");
        launchButton.setOnClickListener(v -> launchTarget());
        layout.addView(launchButton, matchWrap());

        setContentView(layout);
    }

    private void launchTarget() {
        String packageName = packageInput.getText().toString().trim();
        if (packageName.isEmpty()) {
            Toast.makeText(this, "Isi package aplikasi terlebih dahulu", Toast.LENGTH_LONG).show();
            return;
        }
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent == null) {
            Toast.makeText(this,
                "Aplikasi tidak ditemukan. Periksa package name dan pastikan MLBB terpasang.",
                Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivity(launchIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membuka aplikasi: " + e.getMessage(),
                Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }
}
